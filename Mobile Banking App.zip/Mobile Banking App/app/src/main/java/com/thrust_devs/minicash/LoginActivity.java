package com.thrust_devs.minicash;

import android.content.Intent;
import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.thrust_devs.minicash.StorageLib.SessionData;
import com.thrust_devs.minicash.StorageLib.User;

public class LoginActivity extends AppCompatActivity implements View.OnClickListener {
    private Button loginBtn;
    private EditText pin_number;
    DatabaseHelper helper;
    String pin = "";
    private Button registerBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        helper = new DatabaseHelper(this);
        loginBtn = findViewById(R.id.loginBtn);
        pin_number = findViewById(R.id.pin_number);
        registerBtn=findViewById(R.id.registerBtn);
        registerBtn.setOnClickListener(this);
        loginBtn.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.loginBtn:
                Cursor cursor = helper.UserExists(pin_number.getText().toString());
                if (cursor.getCount() > 0) {
                    while (cursor.moveToNext()) {
                        User user = new User();
                        user.setName(cursor.getString(cursor.getColumnIndex(helper.FIRSTNAME)));
                        user.setUser_id(cursor.getString(cursor.getColumnIndex(helper.ID)));
                        user.setLogged(true);
                        new SessionData(getApplicationContext()).storeUser(user);
                        startActivity(new Intent(getApplicationContext(), List_Actions.class));
                        finish();
                    }
                } else {
                    Toast.makeText(this, "wrong pin number", Toast.LENGTH_SHORT).show();
                }
                break;
            case R.id.registerBtn:
                startActivity(new Intent(getApplicationContext(), Register.class));
                finish();
                break;
        }
    }
}
