package com.thrust_devs.minicash;

import android.database.Cursor;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;

import com.thrust_devs.minicash.StorageLib.SessionData;

import java.util.ArrayList;

public class TransactionHistory extends AppCompatActivity {
    private RecyclerView recycle_view;
    ArrayList<Transaction> arrayList;
    DatabaseHelper helper;
    RecyclerView.Adapter adapter;
    TextView messageText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_transaction_history);
        getSupportActionBar().setTitle("Transaction History");
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        arrayList = new ArrayList<>();
        helper = new DatabaseHelper(this);
        recycle_view = findViewById(R.id.recycle_view);
        recycle_view.setLayoutManager(new LinearLayoutManager(this));
        messageText = findViewById(R.id.messageText);
        refresh_transactions();
    }

    private void refresh_transactions() {
        arrayList.clear();
        Cursor cursor = helper.getTransactionHistory(new SessionData(getApplicationContext()).getUserDetails().getUser_id());
        adapter = new TransactionAdapter(arrayList, this);
        RecyclerView.LayoutManager manager = new LinearLayoutManager(this);
        recycle_view.setLayoutManager(manager);
        recycle_view.setAdapter(adapter);
        if (cursor.getCount() > 0) {
            arrayList.clear();
            while (cursor.moveToNext()) {
                Transaction comment = new Transaction();
                comment.setAmount(cursor.getString(cursor.getColumnIndex(helper.AMOUNT)));
                comment.setCharges(cursor.getString(cursor.getColumnIndex(helper.CHARGES)));
                comment.setTransaction_type(cursor.getString(cursor.getColumnIndex(helper.TRANSACTION_TYPE)));
                arrayList.add(comment);
            }
            adapter.notifyDataSetChanged();
            messageText.setVisibility(View.GONE);
        } else {
            messageText.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return super.onSupportNavigateUp();
    }
}
