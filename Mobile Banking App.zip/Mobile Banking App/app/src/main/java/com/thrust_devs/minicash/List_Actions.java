package com.thrust_devs.minicash;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.thrust_devs.minicash.StorageLib.SessionData;

public class List_Actions extends AppCompatActivity implements View.OnClickListener {
    private Button deposit_btn, withdrawBtn, logoutBtn, balanceBtn,transaction_history;
    private TextView user;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list__actions);
        db = new DatabaseHelper(this);
        deposit_btn = findViewById(R.id.deposit_btn);
        withdrawBtn = findViewById(R.id.withdrawBtn);
        logoutBtn = findViewById(R.id.logoutBtn);
        user = findViewById(R.id.user);
        user.setText("Welcome " + new SessionData(this).getUserDetails().getName());
        logoutBtn.setOnClickListener(this);
        withdrawBtn.setOnClickListener(this);
        deposit_btn.setOnClickListener(this);
        balanceBtn = findViewById(R.id.balanceBtn);
        balanceBtn.setOnClickListener(this);
        transaction_history=findViewById(R.id.transaction_history);
        transaction_history.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.deposit_btn:
                startActivity(new Intent(getApplicationContext(), Deposit_activity.class));
                break;
            case R.id.withdrawBtn:
                startActivity(new Intent(getApplicationContext(), Withdraw.class));
                break;
            case R.id.logoutBtn:
                new SessionData(getApplicationContext()).Logout();
                startActivity(new Intent(List_Actions.this, LoginActivity.class));
                finish();
                break;
            case R.id.balanceBtn:
                double balance = db.checkBalance(new SessionData(getApplicationContext()).getUserDetails().getUser_id());
                Toast.makeText(this, "Your balance is " + balance, Toast.LENGTH_SHORT).show();
                break;
            case R.id.transaction_history:
                startActivity(new Intent(List_Actions.this, TransactionHistory.class));
                break;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        boolean isLogged = new SessionData(this).getUserDetails().isLogged();
        if (!isLogged) {
            startActivity(new Intent(getApplicationContext(), LoginActivity.class));
        }

    }
}
