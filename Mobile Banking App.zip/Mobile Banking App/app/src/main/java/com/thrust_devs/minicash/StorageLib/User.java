package com.thrust_devs.minicash.StorageLib;


public class User {
    private String user_id;
    private String name;
    private String login_hash;
    private boolean isLogged;

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLogin_hash() {
        return login_hash;
    }

    public void setLogin_hash(String login_hash) {
        this.login_hash = login_hash;
    }

    public boolean isLogged() {
        return isLogged;
    }

    public void setLogged(boolean logged) {
        isLogged = logged;
    }
}
