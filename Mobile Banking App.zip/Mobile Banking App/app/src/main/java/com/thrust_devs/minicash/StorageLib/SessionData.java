package com.thrust_devs.minicash.StorageLib;

import android.content.Context;
import android.content.SharedPreferences;


public class SessionData {
    private Context context;
    private SharedPreferences USER_PREF;
    private SharedPreferences.Editor USER_EDITOR;

    private SharedPreferences URL_PREF;
    private SharedPreferences.Editor URL_EDITOR;

    public static final String USER_ID = "user_id";
    public static final String NAME = "name";
    public static final String LOGGEDIN = "logged_in";


    public SessionData(Context context) {
        this.context = context;
        USER_PREF = context.getSharedPreferences("user_details", Context.MODE_PRIVATE);
        USER_EDITOR = USER_PREF.edit();
        URL_PREF = context.getSharedPreferences("url_prefs", Context.MODE_PRIVATE);
        URL_EDITOR = URL_PREF.edit();
    }


    public void storeUser(User user) {
        USER_EDITOR.putString(USER_ID, user.getUser_id());
        USER_EDITOR.putString(NAME, user.getName());
        USER_EDITOR.putBoolean(LOGGEDIN, user.isLogged());
        USER_EDITOR.apply();
    }

    public User getUserDetails() {
        User user = new User();
        user.setUser_id(USER_PREF.getString(USER_ID, null));
        user.setName(USER_PREF.getString(NAME, null));
        user.setLogged(USER_PREF.getBoolean(LOGGEDIN, false));
        return user;
    }


    public void Logout() {
        USER_EDITOR.clear();
        USER_EDITOR.apply();
        URL_EDITOR.clear();
        URL_EDITOR.apply();
    }
}
