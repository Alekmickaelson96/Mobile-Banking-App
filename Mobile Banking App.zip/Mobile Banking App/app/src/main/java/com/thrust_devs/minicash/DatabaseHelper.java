package com.thrust_devs.minicash;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;


public class DatabaseHelper extends SQLiteOpenHelper {
    private static String DATABASE = "minicash";
    private static int DB_VERSION = 3;
    public static String ID = "_id";

    public static final String CUSTOMER_TABLE = "customer_table";


    public static final String FIRSTNAME = "firstname";
    public static final String LASTNAME = "lastname";
    public static final String PHONE_NUMBER = "phone_number";
    public static final String PIN_NUMBER = "pin_number";


    public String CREATE_LOGIN_TABLE = "CREATE TABLE " + CUSTOMER_TABLE + "(" + ID + " integer primary key autoincrement," + FIRSTNAME + " TEXT," + LASTNAME + " TEXT," + PHONE_NUMBER + " TEXT," + PIN_NUMBER + " TEXT)";


    public static final String TRANSACTIONS_TABLE = "transactions";

    public static final String TRANSACTION_TYPE = "transaction_type";
    public static final String AMOUNT = "amount";
    public static final String CHARGES = "charges";
    public static final String USER_ID = "user_id";
    public static final String _WHEN_ADDED = "_when_added";


    public String CREATE_TRANSACTIONS_TABLE = "CREATE TABLE " + TRANSACTIONS_TABLE + "(" + ID + " integer primary key autoincrement," + TRANSACTION_TYPE + " TEXT," + AMOUNT + " DOUBLE," + CHARGES + " double," + USER_ID + " TEXT," + _WHEN_ADDED + " TEXT)";


    public DatabaseHelper(Context context) {
        super(context, DATABASE, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        db.execSQL(CREATE_LOGIN_TABLE);
        db.execSQL(CREATE_TRANSACTIONS_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {

        db.execSQL("DROP TABLE IF EXISTS " + CUSTOMER_TABLE);
    }


    public boolean validatePinNumber(String pin) {
        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "SELECT * FROM " + CUSTOMER_TABLE + "  where " + PIN_NUMBER + "=" + pin + ";";
        Cursor c = db.rawQuery(sql, null);
        if (c.getCount() > 0)
            return true;
        return false;
    }


    public boolean hasRegistered() {
        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "SELECT * FROM " + CUSTOMER_TABLE;
        Cursor c = db.rawQuery(sql, null);
        if (c.getCount() > 0)
            return true;
        return false;
    }


    public void deleteAllComments() {
        SQLiteDatabase database = this.getWritableDatabase();
        database.delete(CUSTOMER_TABLE, null, null);
    }


    public void storeData(String table, String columns[], String[] data) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        for (int i = 0; i < data.length; i++) {
            values.put(columns[i], data[i]);
        }
        Long i = db.insert(table, null, values);
        Log.d("insrtedcUSTOM", i + " ");
        db.close();
    }

    public Cursor storedData(String TABLE) {
        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "select * from " + TABLE;
        Cursor c = db.rawQuery(sql, null);
        return c;
    }


    public double checkBalance(String user_id) {
        //get sum deposit
        SQLiteDatabase db = this.getReadableDatabase();
        String sql_deposit = "SELECT sum(" + AMOUNT + ") as deposit_amount FROM " + TRANSACTIONS_TABLE + " WHERE " + USER_ID + "='" + user_id + "' and  TRANSACTION_TYPE='deposit';";
        Cursor cursor_deposit = db.rawQuery(sql_deposit, null);
        cursor_deposit.moveToFirst();


        String sql_withdraw = "SELECT sum(" + AMOUNT + ") as withdraw_amount FROM " + TRANSACTIONS_TABLE + " WHERE " + USER_ID + "='" + user_id + "' and  TRANSACTION_TYPE='withdraw';";
        Cursor cursor_withdraw = db.rawQuery(sql_withdraw, null);
        cursor_withdraw.moveToFirst();


        double deposit_amount = cursor_deposit.getDouble(cursor_deposit.getColumnIndex("deposit_amount"));
        double withdraw_amount = cursor_withdraw.getDouble(cursor_withdraw.getColumnIndex("withdraw_amount"));
        double balance = deposit_amount - withdraw_amount;
        return balance;
    }

    public Cursor getTransactionHistory(String user_id) {
        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "select * from " + TRANSACTIONS_TABLE + " WHERE " + USER_ID + "=" + user_id + " order by " + ID + " DESC";
        Cursor c = db.rawQuery(sql, null);
        return c;
    }

    public void deleteData(String TABLE, int id) {
        SQLiteDatabase database = this.getWritableDatabase();
        String sql = ID + "=" + id;
        database.delete(TABLE, sql, null);

    }


    public Cursor UserExists(String pin) {
        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "SELECT * FROM " + CUSTOMER_TABLE + " WHERE " + PIN_NUMBER + "='" + pin + "';";
        Cursor c = db.rawQuery(sql, null);
        return c;
    }


}
