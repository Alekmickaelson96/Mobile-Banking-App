package com.thrust_devs.minicash;

public class TaxCharges {
    protected double balance;

    public TaxCharges() {
    }

    public double afterTax(double amount) {
        double tax = 0.01 * amount;
        this.balance = amount - tax;
        return balance;
    }

    public double afterBankCharges(double after_tax_amount) {
        if (after_tax_amount >= 500 || after_tax_amount <= 2500) {
            return after_tax_amount - 200;

        } else if (after_tax_amount >= 2501 && after_tax_amount <= 5000) {
            return after_tax_amount-450;

        }
        else if (after_tax_amount >= 5001 && after_tax_amount <= 15000) {
            return after_tax_amount - 1000;

        } else if (after_tax_amount >= 15001 && after_tax_amount <= 30000) {
            return after_tax_amount - 1000;

        } else if (after_tax_amount >= 30001 && after_tax_amount <= 45000) {
            return after_tax_amount - 1550;

        } else if (after_tax_amount >= 45001 && after_tax_amount <= 60000) {
            return after_tax_amount - 1550;

        } else if (after_tax_amount >= 60001 && after_tax_amount <= 125000) {
            return after_tax_amount - 2050;

        } else if (after_tax_amount >= 125001 && after_tax_amount <= 250000) {
            return after_tax_amount - 2050;

        } else if (after_tax_amount >= 250001 && after_tax_amount <= 500000) {
            return after_tax_amount - 2050;

        } else if (after_tax_amount >= 500001 && after_tax_amount <= 1000000) {
            return after_tax_amount - 2500;

        } else if (after_tax_amount >= 1000001 && after_tax_amount <= 2000000) {
            return after_tax_amount - 2500;

        } else if (after_tax_amount >= 2000001 && after_tax_amount <= 4000000) {
            return after_tax_amount - 2550;
        }
        return balance;
    }
}
