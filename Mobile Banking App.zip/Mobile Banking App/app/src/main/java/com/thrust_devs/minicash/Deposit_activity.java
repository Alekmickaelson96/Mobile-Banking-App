package com.thrust_devs.minicash;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.thrust_devs.minicash.StorageLib.SessionData;

public class Deposit_activity extends AppCompatActivity implements View.OnClickListener {
    private EditText amount;
    private Button btn;
    private DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_deposit_activity);
        db = new DatabaseHelper(this);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setTitle("Deposit");
        amount = findViewById(R.id.amount);
        btn = findViewById(R.id.btn);
        btn.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn:
                if (!validateAmount()) {
                    return;
                }
                double amount_before_tax = Double.parseDouble(amount.getText().toString());
                double amount_after_tax = new TaxCharges().afterTax(amount_before_tax);

                double after_bank_charges = new TaxCharges().afterBankCharges(amount_after_tax);

                double charges = Double.parseDouble(amount.getText().toString()) - after_bank_charges;

                String[] columns = {db.TRANSACTION_TYPE, db.AMOUNT, db.CHARGES, db.USER_ID, db._WHEN_ADDED};
                String[] data = {"deposit", String.valueOf(after_bank_charges), String.valueOf(charges), new SessionData(getApplicationContext()).getUserDetails().getUser_id(), ""};
                db.storeData(db.TRANSACTIONS_TABLE, columns, data);
                amount.setText("");
                Toast.makeText(this, "Deposit has successfully been added", Toast.LENGTH_SHORT).show();
                break;
        }
    }

    private boolean validateAmount() {
        if (amount.getText().toString().trim().isEmpty()) {
            Toast.makeText(this, "Amount is required", Toast.LENGTH_SHORT).show();
            requestFocus(amount);
            return false;
        }

        return true;
    }


    private void requestFocus(View view) {
        if (view.requestFocus()) {
            getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_VISIBLE);
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        onBackPressed();
        return super.onSupportNavigateUp();
    }
}
