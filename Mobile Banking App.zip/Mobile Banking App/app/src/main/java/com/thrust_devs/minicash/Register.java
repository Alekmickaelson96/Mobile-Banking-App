package com.thrust_devs.minicash;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Register extends AppCompatActivity implements View.OnClickListener {
    private EditText first_name, last_name, phone_number, pin_number;
    private Button btn;
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        first_name = findViewById(R.id.first_name);
        last_name = findViewById(R.id.last_name);
        phone_number = findViewById(R.id.phone_number);
        pin_number = findViewById(R.id.pin_number);
        btn = findViewById(R.id.btn);
        db = new DatabaseHelper(this);
        btn.setOnClickListener(this);

    }

    @Override
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btn:
                String[] columns = {db.FIRSTNAME, db.LASTNAME, db.PHONE_NUMBER, db.PIN_NUMBER};
                String[] data = {first_name.getText().toString(), last_name.getText().toString(), phone_number.getText().toString()
                        , pin_number.getText().toString()};
                db.storeData(db.CUSTOMER_TABLE, columns, data);
                startActivity(new Intent(getApplicationContext(), LoginActivity.class));
                finish();
                break;
        }
    }
}
